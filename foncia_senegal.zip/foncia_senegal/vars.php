<?php
    
$USER_DB        = "root";
$PASSWORD_DB    = "root";
$NAME_DB        = "foncia_senegal";
$HOST_DB		= "localhost";
?>